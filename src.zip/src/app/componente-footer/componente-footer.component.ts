import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componente-footer',
  templateUrl: './componente-footer.component.html',
  styleUrls: ['./componente-footer.component.scss']
})
export class ComponenteFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
