export enum ActiveCommentTypeEnum {
  replying = 'replying',
  editing = 'editing',
}
