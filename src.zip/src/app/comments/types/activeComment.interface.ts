import { ActiveCommentTypeEnum } from './activeCommentType.enum';

export interface ActiveCommentInterface {
  id: string;
  type: ActiveCommentTypeEnum;
}
