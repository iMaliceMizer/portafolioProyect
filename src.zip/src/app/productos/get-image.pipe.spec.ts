import { GetImagePipe } from './get-image.pipe';

describe('GetImagePipe', () => {
  it('create an instance', () => {
    const pipe = new GetImagePipe();
    expect(pipe).toBeTruthy();
  });
});
