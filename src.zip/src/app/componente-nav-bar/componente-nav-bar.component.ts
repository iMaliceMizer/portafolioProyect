import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componente-nav-bar',
  templateUrl: './componente-nav-bar.component.html',
  styleUrls: ['./componente-nav-bar.component.scss']
})
export class ComponenteNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
